﻿namespace Interface
{
    public class Class1
    {

    }
}