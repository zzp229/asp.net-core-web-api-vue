﻿namespace Service
{
    public class Class1
    {

    }
}