﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model.Enum
{
    /// <summary>
    /// 上传时候会用到的枚举
    /// </summary>
    public enum UploadMode
    {
        Local = 1,
        Qiniu = 2
    }
}
