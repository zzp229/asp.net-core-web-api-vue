export default interface UserInfo {
    Id: string
    NickName: string
    Name: string
    Image: string
    UserType: string
    exp: number
}