export default interface ApiResult {
    IsSuccess: boolean
    Msg: string
    Result: any
}