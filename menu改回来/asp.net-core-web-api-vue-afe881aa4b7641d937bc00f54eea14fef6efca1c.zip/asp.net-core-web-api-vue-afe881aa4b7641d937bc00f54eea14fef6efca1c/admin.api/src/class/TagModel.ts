export default interface TagModel {
    Name: string
    Index: string
    Checked: boolean
}