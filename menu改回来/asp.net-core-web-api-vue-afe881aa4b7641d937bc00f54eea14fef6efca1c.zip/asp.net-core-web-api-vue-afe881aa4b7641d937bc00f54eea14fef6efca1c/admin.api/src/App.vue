<script setup lang="ts">
</script>

<template>
  <!-- 路由标签，组件加载到这里 -->
  <router-view></router-view>
</template>

<style scoped lang="scss">

</style>
